"""Intersections volumiques des assemblages nominaux, via OpenSCAD/CGAL.

Les contacts de surface sont autorises. Aucun calcul de resistance ou de nappe.
Les wrappers sont temporaires ; le resultat est livre avec les STL.
"""
from pathlib import Path
import json
import subprocess
import tempfile

import numpy as np

import trimesh

ROOT = Path(__file__).resolve().parent
SCAD = "C:/Program Files/OpenSCAD/openscad.com"
SOURCE = (ROOT / "modular_camera_rig.scad").as_posix()
MOUNT = (ROOT / "camera_mount_v2_pi25.scad").as_posix()
PITCH = 110
CASES = {
    "berceau_support_v2": ["cradle();", 'translate([0,0,6]) mount();'],
    "cale_support_v2": ["translate([0,-32,0]) cradle_key();", 'translate([0,0,6]) mount();'],
    "cale_berceau": ["translate([0,-32,0]) cradle_key();", "cradle();"],
    "rail_rail": ["rail();", "translate([110,0,0]) rail();"],
    "rail_clavette": ["rail();", "seated_key();"],
    "tenon_clavette": ["tongue();", "seated_key();"],
    "rail_berceau": ["translate([-55,0,-16]) rail();", "cradle();"],
    "rail_pied_diagonale": ["translate([-55,0,-16]) rail();", "shoe(-1);"],
    "rail_montant": ["translate([-55,0,-16]) rail();", "mast_lower();"],
    "montant_bas_milieu": ["mast_lower();", "translate([0,0,100]) mast_middle();"],
    "montant_milieu_haut": ["mast_middle();", "translate([0,0,100]) mast_top();"],
    "montant_berceau": ["mast_top();", "translate([0,0,100]) cradle();"],
    "pied_diagonale_gauche": ["shoe(-1);", "translate([0,0,32]) rotate([0,-atan2(208,192),0]) brace();"],
    "pied_diagonale_droit": ["shoe(1);", "translate([0,0,32]) rotate([0,-(180-atan2(208,192)),0]) brace();"],
    "diagonale_diagonale": ["brace();", "translate([sqrt(192*192+208*208)/3,0,0]) brace();"],
    "sommet_diagonale_gauche": ["mast_top();", "translate([-28,0,40]) rotate([0,-atan2(208,192),0]) translate([-sqrt(192*192+208*208)/3,0,0]) brace();"],
    "sommet_diagonale_droit": ["mast_top();", "translate([28,0,40]) rotate([0,-(180-atan2(208,192)),0]) translate([-sqrt(192*192+208*208)/3,0,0]) brace();"],
}


def main():
    results = []
    with tempfile.TemporaryDirectory(prefix="pavois-cad-") as tmp:
        temp = Path(tmp)
        for name, pair in CASES.items():
            source, output = temp / f"{name}.scad", temp / f"{name}.stl"
            source.write_text(f'use <{SOURCE}>\nuse <{MOUNT}>\nintersection() {{\n'+"\n".join(pair)+"\n}\n", encoding="utf-8")
            proc = subprocess.run([SCAD, "-o", str(output), str(source)],
                                  capture_output=True, text=True, encoding="utf-8", errors="replace")
            log = proc.stdout + proc.stderr
            if "ERROR:" in log or any("WARNING:" in line and "2-manifold" not in line
                                       for line in log.splitlines()):
                raise RuntimeError(log)
            if output.exists():
                with np.errstate(invalid="ignore", divide="ignore"):
                    volume = abs(float(trimesh.load_mesh(output).volume))
            elif "Current top level object is empty" in log:
                volume = 0
            else:
                raise RuntimeError(f"Exit {proc.returncode}: {log!r}; source={source.read_text()}")
            record = {"pair": name, "intersection_mm3": round(volume, 6), "pass": volume < 0.01,
                      "surface_contact_only": "2-manifold" in log and volume < 0.01}
            results.append(record)
            print(record, flush=True)
    report = {"scope": "Named mating pairs at default dimensions; not a structural or cable test.", "pairs": results}
    (ROOT / "modular_rig" / "assembly_checks.json").write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    if not all(r["pass"] for r in results):
        raise SystemExit("Interferences a corriger")


if __name__ == "__main__":
    main()
