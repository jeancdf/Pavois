// PAVOIS — banc de chambre V0.1, millimetres. PLA / A1 mini.
// Source des supports EXISTANTS : camera_mount_v2_pi25.scad (non modifie).
// Prototype : ajustements et rigidite a valider physiquement avant calibration.
use <camera_mount_v2_pi25.scad>

/* [Vue] */
view = "assembly"; // [assembly,exploded,part,cradle_detail]
part = "rail"; // [rail,rail_end,cradle,cradle_key,joint_key,mast_lower,mast_middle,mast_top,brace,shoe_left,shoe_right,coupon_socket,coupon_tongue]
camera_count = 3; // [2,3]
show_mounts = true;
show_axes = true;
show_keys = true;

/* [Dimensions] */
rig_width = 1000;         // largeur hors tout des berceaux
rise = 300;               // difference de hauteur des plans d'appui V2
fit = 0.25;               // jeu PAR FACE du tenon (pas jeu diametral)
coupon_fit = 0.25;

/* [Hidden] */
$fn = 32;
eps = 0.02;
cw = 120;
pitch = (rig_width-cw)/8;
rail_count = 9;
rail_top = 36;
mast_pitch = rise/3;
brace_base_x = 2*pitch;
brace_top_x = 28;
brace_base_z = 32;
brace_top_z = rise-60;
brace_dx = brace_base_x-brace_top_x;
brace_dz = brace_top_z-brace_base_z;
brace_angle = atan2(brace_dz,brace_dx);
brace_length = sqrt(brace_dx*brace_dx+brace_dz*brace_dz);
brace_pitch = brace_length/3;
explode = view=="exploded" ? 1 : 0;
// Centre carte camera dans le modele V2 ; ce n'est PAS le centre optique calibre.
camera_board_z = 130;
base_front = (-130*cos(70)-2)/sin(70);

assert(camera_count==2 || camera_count==3,"camera_count : 2 ou 3");
assert(fit>=0.10 && fit<=0.45,"Jeu par face hors plage prototype 0.10..0.45");
assert(pitch>=75 && pitch+24<=170,"Largeur incompatible avec segments A1 mini");
assert(mast_pitch>=90 && mast_pitch+48<=170,"Surhauteur incompatible avec montant");
assert(brace_pitch+24<=170 && brace_pitch>=55,"Diagonales hors plage");

// Interface universelle : X vers l'interieur de la douille, Y transversal.
// Coin biseaute = detrompage. Tenon 24 mm ; appui axial sur epaulement.
module profile(clearance=0) {
    offset(delta=-clearance)
        polygon([[-10,-8],[10,-8],[10,5],[7,8],[-10,8]]);
}
module along_x() { rotate([90,0,90]) children(); }
module tongue(clearance=fit) {
    difference() {
        translate([-eps,0,0]) along_x() linear_extrude(24+eps) profile(clearance);
        translate([7,-25,-5]) cube([7,50,10]);
    }
}
module socket(clearance=fit) {
    translate([-eps,0,0]) along_x() linear_extrude(24.5+eps) profile();
    // Passage de clavette : decale de 2 mm par rapport au tenon.
    translate([9,-55,-5-clearance]) cube([9,110,10+2*clearance]);
}
// Clavette progressive : largeur 5.8 -> 4.2 sur 56 mm, sans clip flexible.
// Dans l'assemblage, le contact est nominal ; le coupon decide du serrage reel.
module joint_key() {
    union() {
        translate([0,0,-4.5]) linear_extrude(9)
            polygon([[0,-28],[5.8,-28],[4.2,28],[0,28]]);
        translate([-2,-33,-4.5]) cube([10,5.05,9]);
    }
}
module seated_key() { translate([9,-10,0]) joint_key(); }
module keyed_connection() {
    if(show_keys) color("#ef9e35") seated_key();
}
// Plateau horizontal : interface dirigee vers le bas depuis le dessus.
module downward() { rotate([0,90,0]) children(); }
module upward() { rotate([0,-90,0]) children(); }

module rail(last=false) {
    difference() {
        union() {
            translate([0,-20,-16]) cube([pitch,40,32]);
            // Pied integre, donc appui sous CHAQUE segment sur la table.
            translate([pitch/2-25,-80,-20]) cube([50,160,4.05]);
            if(!last) translate([pitch,0,0]) tongue();
        }
        socket();
        translate([pitch/2,0,16]) downward() socket();
    }
}

// Berceau : le socle reste horizontal. Contacts uniquement sur les bords
// lateraux du pied et deux zones arriere, hors nervure centrale de 10 mm.
// Le V2 entre depuis l'avant (-Y), puis vient contre les butees Y=40.
module cradle() {
    difference() {
        union() {
            translate([-60,-56,0]) cube([120,104,6]);
            translate([0,0,0]) downward() tongue();
            // Cote gauche de reference, puis levre anti-soulevement.
            translate([-56,-40,6-eps]) cube([6,80,10]);
            translate([-56,-40,12.6]) cube([9,80,3.4]);
            // Cote droit : logement pour cale longitudinale amovible.
            translate([54,-40,6-eps]) cube([6,84,10]);
            translate([48,-40,12.6]) cube([12,80,3.4]);
            for(x=[-43,27]) translate([x,40,6-eps]) cube([16,6,8]);
        }
        // Pas de paroi devant le pied : acces insertion / extraction.
    }
}
// Cale laterale entree depuis -Y ; pousse le pied contre X=-50.
// Bord droit fixe X=54 ; epaisseur progressive. A garder amovible.
module cradle_key() {
    union() {
        translate([0,0,6.3]) linear_extrude(5.8)
            polygon([[49.6,-49],[54,-49],[54,40],[50.8,40]]);
        translate([49.6,-55,6.3]) cube([10.4,6.05,5.8]);
    }
}

module mast_lower() {
    union() {
        translate([-16,-20,0]) cube([32,40,mast_pitch]);
        downward() tongue();
        translate([0,0,mast_pitch]) upward() tongue();
    }
}
module mast_middle() {
    difference() {
        union() {
            translate([-16,-20,0]) cube([32,40,mast_pitch]);
            translate([0,0,mast_pitch]) upward() tongue();
        }
        upward() socket();
    }
}
// Position locale des douilles du sommet sur le dernier troncon du montant.
module hub_frame(side) {
    translate([side*brace_top_x,0,brace_top_z-2*mast_pitch])
        rotate([0,-(side<0 ? brace_angle : 180-brace_angle),0]) children();
}
module mast_top() {
    difference() {
        union() {
            translate([-16,-20,0]) cube([32,40,mast_pitch]);
            for(side=[-1,1]) hub_frame(side)
                translate([0,-20,-16]) cube([34,40,32]);
        }
        upward() socket();
        translate([0,0,mast_pitch]) downward() socket();
        for(side=[-1,1]) hub_frame(side) socket();
    }
}
module brace() {
    difference() {
        union() {
            translate([0,-20,-16]) cube([brace_pitch,40,32]);
            translate([brace_pitch,0,0]) tongue();
        }
        socket();
    }
}
module shoe(side=-1) {
    union() {
        translate([-32,-30,0]) cube([64,60,12]);
        downward() tongue();
        translate([0,0,brace_base_z])
            rotate([0,-(side<0 ? brace_angle : 180-brace_angle),0])
                union() {
                    translate([-28,-20,-16]) cube([28,40,32]);
                    tongue();
                }
    }
}
module coupon_socket() {
    difference() {
        translate([0,-20,-16]) cube([32,40,32]);
        socket(coupon_fit);
        translate([29,0,16-0.6]) linear_extrude(1)
            text(str(coupon_fit),size=4,halign="right",valign="center");
    }
}
module coupon_tongue() {
    union() {
        translate([-8,-20,-16]) cube([8,40,32]);
        tongue(coupon_fit);
    }
}

module existing_mount() {
    // Reconstruire le source V2 : le STL historique contient de petits
    // fragments degeneres qui empechent certaines operations CGAL.
    color([0.66,0.71,0.76,0.72]) mount();
}
module optical_axis() {
    color("#df4e48") translate([0,0,6+camera_board_z])
        rotate([70,0,0]) cylinder(r=1.1,h=250);
}
module cradle_assembly() {
    color("#4f9cb4") cradle();
    if(show_keys) color("#ef9e35") translate([0,-32,0]) cradle_key();
    if(show_mounts) translate([0,-explode*65,6+explode*30]) existing_mount();
    if(show_axes) optical_axis();
    downward() keyed_connection();
}
module assembly() {
    // Tous les pieds sont a Z=0 ; le dessus du rail est Z=36.
    for(i=[0:8]) {
        x=(i-4)*pitch;
        translate([x-pitch/2+(i-4)*explode*10,0,20]) {
            color(i%2==0 ? "#405566" : "#60798a") rail(i==8);
            if(i>0) keyed_connection();
        }
    }
    for(side=[-1,1]) translate([side*4*pitch,0,rail_top+explode*40])
        cradle_assembly();
    if(camera_count==3) {
        translate([0,0,rail_top+explode*40]) {
            color("#60798a") mast_lower();
            downward() keyed_connection();
        }
        translate([0,0,rail_top+mast_pitch+explode*65]) {
            color("#405566") mast_middle();
            upward() keyed_connection();
        }
        translate([0,0,rail_top+2*mast_pitch+explode*90]) {
            color("#60798a") mast_top();
            upward() keyed_connection();
            for(side=[-1,1]) hub_frame(side) keyed_connection();
        }
        translate([0,0,rail_top+rise+explode*120]) cradle_assembly();
        for(side=[-1,1]) {
            translate([side*brace_base_x,0,rail_top+explode*25]) {
                color("#4f9cb4") shoe(side);
                downward() keyed_connection();
            }
            translate([side*brace_base_x,0,rail_top+brace_base_z])
                rotate([0,-(side<0 ? brace_angle : 180-brace_angle),0])
                    for(j=[0:2]) translate([j*brace_pitch+explode*(j+1)*18,0,0]) {
                        color(j%2==0 ? "#60798a" : "#405566") brace();
                        keyed_connection();
                    }
        }
    }
}

// Orientation de fabrication ; minimum Z=0. Supports locaux necessaires
// sous certains tenons / levres : verifier le tranchage (voir notice).
module on_side() { translate([0,0,20]) rotate([90,0,0]) children(); }
module print_part() {
    if(part=="rail") translate([0,0,20]) rail();
    else if(part=="rail_end") translate([0,0,20]) rail(true);
    else if(part=="cradle") translate([0,0,60]) rotate([0,90,0]) cradle();
    else if(part=="cradle_key") translate([0,0,-6.3]) cradle_key();
    else if(part=="joint_key") translate([0,0,4.5]) joint_key();
    else if(part=="mast_lower") on_side() mast_lower();
    else if(part=="mast_middle") on_side() mast_middle();
    else if(part=="mast_top") on_side() mast_top();
    else if(part=="brace") on_side() brace();
    else if(part=="shoe_left") translate([0,0,30]) rotate([90,0,0]) shoe(-1);
    else if(part=="shoe_right") translate([0,0,30]) rotate([90,0,0]) shoe(1);
    else if(part=="coupon_socket") on_side() coupon_socket();
    else if(part=="coupon_tongue") on_side() coupon_tongue();
    else assert(false,str("Piece inconnue : ",part));
}

echo(str("Largeur hors tout = ",rig_width," mm; entraxe lateral nominal = ",8*pitch));
echo(str("Plans d'appui V2 : Z=",rail_top+6," / ",rail_top+rise+6));
echo(str("Centres cartes nominaux : X=+/-",4*pitch," Z=",rail_top+6+130,
         "; C3 X=0 Z=",rail_top+rise+6+130));
if(view=="part") print_part();
else if(view=="assembly" || view=="exploded") assembly();
else if(view=="cradle_detail") cradle_assembly();
else assert(false,"Vue inconnue");
