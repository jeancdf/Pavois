# Banc modulaire PAVOIS — ébauche V0.1

Banc en PLA pour **deux ou trois supports V2 existants**, posé sur une table
rigide. Aucun ajout de vis, insert ou aimant : des tenons détrompés et des
clavettes imprimées positionnent et serrent les pièces. Les vis déjà présentes
sur les supports caméra restent en place.

**Commencer par les éprouvettes, puis un seul berceau.** Cette version est un
prototype géométrique, pas un assemblage déjà validé par impression. Ne pas
lancer toutes les pièces avant d'avoir vérifié leur ajustement.

![Banc avec trois supports ; gris : supports V2, bleu : nouvelles pièces, orange : clavettes, rouge : axes théoriques](modular_rig/assembly_3.png)

## Géométrie et utilisation d'OpenSCAD

Ouvrir **`modular_camera_rig.scad`**, en gardant
`camera_mount_v2_pi25.scad` dans le même dossier. F5 affiche le modèle ; F6
calcule la géométrie avant export. Les supports gris représentent le plastique
existant ; les cartes, objectifs, refroidisseurs et câbles ne sont pas modélisés.

| Paramètre | Valeur livrée | Utilité |
|---|---:|---|
| `view` | `"assembly"` | `"exploded"`, `"part"` ou `"cradle_detail"` également disponibles |
| `camera_count` | 3 | Passer à 2 masque le montant, les diagonales et le support central |
| `part` | `"rail"` | Pièce à afficher/exporter quand `view="part"` |
| `rig_width` | 1000 mm | Largeur totale des berceaux ; modifie la traverse et les diagonales |
| `rise` | 300 mm | Surélévation du troisième plan d'appui ; modifie montant et diagonales |
| `fit` | 0,25 mm | Retrait du tenon par face, ajustable après les éprouvettes |
| `coupon_fit` | 0,25 mm | Retrait propre aux éprouvettes |
| `show_mounts`, `show_axes`, `show_keys` | `true` | Affichages de référence |

Les STL livrés correspondent **uniquement aux valeurs par défaut**. Modifier un
paramètre dans OpenSCAD ne modifie pas les STL déjà exportés. Les assertions
limitent les dimensions manifestement incompatibles ; elles ne remplacent pas
le contrôle des assemblages après une modification de largeur ou de hauteur.

Le banc occupe environ **1000 × 170 mm**, clavettes comprises ; prévoir une zone
libre de **1000 × 400 mm** pour manipuler les pièces et faire passer les câbles.
Chaque tronçon repose sur un pied de 160 mm de profondeur. Le poids ne porte
donc pas uniquement sur les raccords. La stabilité avec l'électronique et les
câbles reste à essayer.

Les supports conservent leur élévation nominale de **20°** et regardent vers
**−Y**. X est l'axe de la traverse, Z monte depuis la table ; ce repère local
n'est pas automatiquement le repère géographique du logiciel PAVOIS.

| Référence mécanique | X (mm) | Y (mm) | Z (mm) |
|---|---:|---:|---:|
| Origine du V2 gauche, plan d'appui | −440 | 0 | 42 |
| Origine du V2 droit, plan d'appui | +440 | 0 | 42 |
| Origine du V2 central, plan d'appui | 0 | 0 | 342 |
| Centre de carte nominal gauche | −440 | 0 | 172 |
| Centre de carte nominal droit | +440 | 0 | 172 |
| Centre de carte nominal central | 0 | 0 | 472 |

L'entraxe latéral nominal est **880 mm**. Les centres de cartes sont les
références de construction du source V2, **pas les centres optiques calibrés**.
Les axes rouges partent de ces références. Une calibration optique demeure
nécessaire ; aucune précision angulaire réelle n'est garantie par le CAD.

![Configuration à deux caméras](modular_rig/assembly_2.png)

## Pièces à imprimer

Les fichiers se trouvent dans `modular_rig/`. Les quantités ci-dessous sont
les **totaux** pour chaque configuration, hors éprouvettes et pièces de réserve.
Les trois supports V2 sont réutilisés, donc absents de cette liste.

| STL | 2 caméras | 3 caméras | Fonction |
|---|---:|---:|---|
| `rail.stl` | 8 | 8 | Tronçon de 110 mm, tenon supplémentaire de 24 mm |
| `rail_end.stl` | 1 | 1 | Dernier tronçon, sans tenon sortant |
| `cradle.stl` | 2 | 3 | Berceau du socle V2 |
| `cradle_key.stl` | 2 | 3 | Cale latérale du socle |
| `joint_key.stl` | 10 | 24 | Clavette universelle de raccord |
| `mast_lower.stl` | 0 | 1 | Bas du montant, deux tenons |
| `mast_middle.stl` | 0 | 1 | Milieu du montant |
| `mast_top.stl` | 0 | 1 | Sommet, douilles pour les diagonales |
| `brace.stl` | 0 | 6 | Trois tronçons par diagonale |
| `shoe_left.stl` | 0 | 1 | Pied de diagonale gauche |
| `shoe_right.stl` | 0 | 1 | Pied de diagonale droit |

Soit **23 nouvelles pièces à deux caméras, 50 à trois caméras**. Les mêmes rails
servent aux deux configurations ; les ouvertures libres restent inutilisées.

### Réglages de départ pour le PLA

- Buse 0,4 mm, couches 0,20 mm, **5 parois**, 5 couches dessus/dessous,
  remplissage de départ 20 %. Ce sont des réglages d'essai, pas une validation
  de résistance.
- Clavettes et petites éprouvettes : remplissage 100 %.
- Conserver les orientations des STL. Les rails reposent sur leurs pieds ;
  les éléments du montant et des diagonales sont couchés sur le côté ; le
  berceau est sur sa tranche latérale ; les clavettes sont à plat.
- **Prévoir des supports locaux** sous les tenons en porte-à-faux et les
  portions de lèvres ou plaques sans appui. Inspecter les couches dans Bambu
  Studio : certains plafonds de douilles nécessitent un pont ou un support
  accessible. Ces STL ne sont pas annoncés « sans supports ».
- Éviter les supports difficiles à extraire au fond des douilles. Nettoyer les
  surfaces de contact sans agrandir arbitrairement les logements.
- Toutes les pièces tiennent dans 170 mm par axe ; les rails font au maximum
  **134 × 160 × 36 mm**. Vérifier aussi la place du brim et des supports sur le
  plateau 180 mm de l'A1 mini. Température et ventilation : profil de ton PLA.

### Éprouvettes avant le banc complet

Imprimer les trois couples `coupon_socket_15/25/35.stl` et
`coupon_tongue_15/25/35.stl`, plus une `joint_key.stl`. Les suffixes désignent
**0,15 / 0,25 / 0,35 mm par face**. Marquer les tenons pour ne pas les mélanger ;
les douilles portent leur valeur en creux.

1. Enfoncer le tenon jusqu'à son épaulement, coin biseauté du bon côté.
2. Introduire la petite extrémité de la clavette dans le passage transversal.
   Le côté droit de la clavette vient contre la paroi fixe de la douille ; sa
   face inclinée pousse le tenon vers son épaulement.
3. Choisir le jeu qui s'assemble à la main, se bloque sans marteau et se
   démonte sans déformer le PLA. La clavette n'a pas à rentrer jusqu'à sa tête.
4. Répéter cinq fois. Si ça reste lâche ou si ça blanchit/fissure, corriger le
   jeu ou la cale avant d'imprimer le reste.
5. Imprimer ensuite **un berceau, sa cale et un rail** pour vérifier le vrai
   socle V2, la lèvre anti-soulèvement et la place des câbles.

La position représentée des clavettes est une position nominale de présentation,
sans interférence volumique ; leur course finale dépend du serrage réel.

## Montage

![Vue éclatée indicative ; les décalages facilitent la lecture et ne sont pas un chemin d'insertion](modular_rig/exploded.png)

1. Sur une table plane, aligner les **8 rails + le rail terminal à droite**.
   Enfoncer chaque tenon dans la douille suivante jusqu'au contact des
   épaulements. Poser les huit clavettes transversales, têtes accessibles côté
   avant (−Y). Tous les pieds doivent toucher la table.
2. Placer les deux berceaux dans les douilles du premier et du dernier tronçon,
   vers le bas. Les butées arrière du berceau regardent vers +Y. Verrouiller
   chaque berceau avec une clavette introduite depuis l'avant du rail.
3. Sans cale latérale, glisser chaque socle V2 depuis l'avant sous les lèvres
   jusqu'aux deux butées arrière. Le côté gauche s'appuie contre sa référence.
   Introduire la cale longitudinale **à droite**, pointe vers l'arrière,
   jusqu'au maintien du socle. Elle doit rester extractible à la main.
4. Pour trois caméras, préassembler **hors de la traverse** le montant à trois
   étages, les deux diagonales à trois tronçons et leurs pieds. Engager les
   pièces avant de serrer les clavettes : ce triangle forme une boucle fermée.
   La pièce supérieure reçoit les deux tenons de diagonales.
5. Descendre cet ensemble dans les **trois douilles alignées** : montant au
   centre (tronçon 5), pieds sur les tronçons 3 et 7. Engager les trois tenons
   verticaux ensemble, puis serrer leurs clavettes et celles du triangle.
6. Ajouter le troisième berceau au sommet, puis le support V2 et sa cale.
   Accompagner les câbles avec du mou ; aucun câble ne doit tirer sur une carte
   ni être pincé sous un socle. Vérifier les connecteurs du Pi et les nappes
   réels, dont le volume n'est pas représenté.

Pour revenir à deux caméras, retirer d'abord le troisième V2 et son berceau,
libérer les trois clavettes de pied du triangle, puis soulever le module
central complet. Les rails et les deux berceaux latéraux restent en place.

![Berceau V2 : butées arrière, lèvres latérales et cale orange accessible à droite](modular_rig/cradle_detail.png)

## Vérifications et limites

Les rapports `verification.json` et `assembly_checks.json` accompagnent les
STL. Le premier contrôle les dimensions, la fermeture, l'orientation des faces,
le volume positif, l'unicité du solide et le contact avec le plateau. Le second
mesure les intersections de **17 couples d'assemblage nommés**, aux dimensions
par défaut. Les contacts de surface sans volume sont permis. Ce contrôle ciblé
n'est pas une simulation de toutes les trajectoires de montage.

Le STL historique V2 contient de petits fragments dégénérés : les références
visuelles et les contrôles de contact sont reconstruits depuis **son source
OpenSCAD**, sans modifier les fichiers V2 existants. Le test du vrai support
imprimé reste donc indispensable.

À faire après impression :

- Charger progressivement avec les supports équipés : aucune bascule, aucun
  pied soulevé, aucun raccord qui glisse. Ne pas transporter le banc chargé
  en le prenant par ses extrémités.
- Marquer un repère et viser une cible fixe. Photographier sa position dans
  chaque caméra après cinq démontages/remontages, à réglages optiques constants.
  Consigner les écarts en pixels plutôt que supposer des angles parfaits.
- Laisser l'ensemble chargé une heure et refaire la mesure pour repérer une
  flexion ou un déplacement. L'absence de défaut visible ne démontre pas une
  précision métrologique.
- Présenter un damier dans les trois champs et calibrer les poses relatives.
  Les IMU ne remplacent pas cette calibration optique.

### Régénérer les livrables

Avec Python 3, `numpy`, `trimesh` et OpenSCAD installés :

```powershell
python mounts/export_modular_rig.py
python mounts/check_modular_rig.py
```

L'exporteur accepte `--openscad`, `--width`, `--rise`, `--fit` et `--images-only`.
Exemple après sélection du coupon :

```powershell
python mounts/export_modular_rig.py --fit 0.15
```

Le vérificateur d'assemblage utilise les **dimensions nominales et le jeu
0,25 mm** du prototype ; adapter ses cas avant de l'utiliser pour une variante.
Les journaux `.log` sont conservés localement et exclus de Git. Aucun changement
du logiciel de détection ou de sa configuration n'est effectué.
